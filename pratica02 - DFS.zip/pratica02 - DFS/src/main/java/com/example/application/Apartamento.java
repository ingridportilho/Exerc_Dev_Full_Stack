package com.example.application;

public class Apartamento {
    private int numero;
    private int andar;
    private double metragem;
    private String situacao;

    public Apartamento(int numero, int andar, double metragem, String situacao){
        this.numero = numero;
        this.andar = andar;
        this.metragem = metragem;
        this.situacao = situacao;
    }

    public int getNumero(){
        return this.numero;
    }
    public int getAndar(){
        return this.andar;
    }
    public double getMetragem(){
        return this.metragem;
    }
    public String getSituacao(){
        return this.situacao;
    }

    public void setNumero(int numero){
        this.numero = numero;
    }

    public void setAndar(int andar){
        this.andar = andar;
    }

    public void setMetragem(int metragem){
        this.metragem = metragem;
    }

    public void setSituacao(String situacao){
        this.situacao = situacao;
    }
}
