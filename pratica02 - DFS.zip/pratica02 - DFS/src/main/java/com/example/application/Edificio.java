package com.example.application;

import java.util.ArrayList;

public class Edificio {
    private String nome;
    private String endereco;
    ArrayList<Apartamento> apartamentos = new ArrayList<>();

    public Edificio(String nome, String endereco){
        this.nome = nome;
        this.endereco = endereco;
    }

    public void adicionarApartamentos(Apartamento apartamento){
        apartamentos.add(apartamento);
    }

    public ArrayList<Apartamento> listarApartamentos(){
        return apartamentos;
    }

    public String getNome(){
        return this.nome;
    }

    public String getEndereco(){
        return this.endereco;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public void setEndereco(String endereco){
        this.endereco = endereco;
    }
    
}
